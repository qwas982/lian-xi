use std::io;
use std::io::prelude::*;

use lexer;
use parser;
use env::EnvRef;

pub fn run(env: &EnvRef) {
    let mut i = 0;

    loop {
        let mut line = String::new();
        io::stdout().write(b"zh_hans_scheme_rs> ").unwrap();
        io::stdout().flush().unwrap();
        io::stdin().read_line(&mut line).unwrap();

        let tokens = lexer::tokenize(&mut line.chars().peekable());
        let sexprs = parser::parse(tokens);

        match sexprs {
            Ok(sexprs) => {
                for sexpr in sexprs {
                    let evaluated = sexpr.eval(env);

                    match evaluated {
                        Ok(evaluated) => {
                            if !evaluated.is_unspecified() {
                                println!("计数 {} = {}", i, evaluated);
                                env.define(format!("计数 {}", i), evaluated);
                                i += 1;
                            }
                        },
                        Err(e) => println!("{}", e)
                    }
                }
            },
            Err(e) => println!("{}", e)
        }
    }
}
