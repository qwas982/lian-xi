pub mod lang;
pub mod equivalence;
#[macro_use]
pub mod numeric;
pub mod ordering;
pub mod conditionals;
pub mod list;
#[macro_use]
pub mod string;
pub mod io;
pub mod system;
pub mod prelude;
pub mod meta;

use primitives::prelude::PRELUDE;
use env::{EnvRef, EnvValues};
use lexer::tokenize;
use parser::parse;
use serr::SResult;

pub fn load_prelude(env: &EnvRef) -> SResult<()> {
    for sexpr in parse(tokenize(&mut PRELUDE.to_string().chars().into_iter().peekable()))? {
        sexpr.eval(&env)?;
    }
    Ok(())
}

pub fn env() -> EnvValues {
    environment! {
        "类型的"        => meta::type_of,
        "转换-类型"  => meta::convert_type,

        "定义"      => lang::define,
        "设置!"        => lang::set,
        "λ"           => lang::lambda,
        "兰姆达"      => lang::lambda,
        "应用"       => lang::apply,
        "让"         => lang::let_,
        "让*"        => lang::let_star,
        "让递归"      => lang::let_rec,
        "引号"       => lang::quote,
        "准引号"  => lang::quasiquote,
        "退出"        => lang::exit,

        "相等?"   => equivalence::eqv_qm,
        "等于?"    => equivalence::eq_qm,
        "等号?" => equivalence::equal_qm,

        "+"  => |args| numeric::calc('+', args),
        "-"  => |args| numeric::calc('-', args),
        "*"  => |args| numeric::calc('*', args),
        "/"  => |args| numeric::calc('/', args),
        "余数"   => numeric::remainder,
        "模数"      => numeric::modulo,
        "分子"   => numeric::numerator,
        "分母" => numeric::denominator,
        "平方根"        => call_float_fun!(sqrt),
        "求幂"        => call_float_fun!(sqrt),
        "向上取整"     => call_float_fun!(ceil),
        "向下取整"       => call_float_fun!(floor),
        "截断"    => call_float_fun!(trunc),
        "四舍五入"       => call_float_fun!(round),
        "指数"         => call_float_fun!(exp),
        "对数"         => call_float_fun!(ln, log),
        "正弦"         => call_float_fun!(sin),
        "余弦"         => call_float_fun!(cos),
        "正切"         => call_float_fun!(tan),
        "反正弦"        => call_float_fun!(asin),
        "反余弦"        => call_float_fun!(acos),
        "反正切"        => call_float_fun!(atan, atan2),
        "号码->串" => numeric::number_string,
        "串->号码" => numeric::string_number,

        "<"  => ordering::lt,
        ">"  => ordering::gt,
        "<=" => ordering::lte,
        ">=" => ordering::gte,
        "="  => ordering::eq,

        "条件" => conditionals::cond,
        "情况" => conditionals::case,
        "与"  => conditionals::and,
        "或"   => conditionals::or,

        "构造"   => list::cons,
        "切头"    => list::car,
        "切尾"    => list::cdr,
        "追加" => list::append,
        "列表-复制" => list::list_copy,

        "串-大写"         => call_str_fun!(to_uppercase),
        "串-小写"       => call_str_fun!(to_lowercase),
        "串-长度"         => call_str_fun!(len),
        "印刻-大写"           => call_chr_fun!(to_uppercase !),
        "印刻-小写"         => call_chr_fun!(to_lowercase !),
        "印刻-大写-情况?"      => call_chr_fun!(is_uppercase),
        "印刻-小写-情况?"      => call_chr_fun!(is_lowercase),
        "印刻-字母?"      => call_chr_fun!(is_alphabetic),
        "印刻-数字?"         => call_chr_fun!(is_numeric),
        "印刻-字母数字?"    => call_chr_fun!(is_alphanumeric),
        "印刻-空格?"      => call_chr_fun!(is_whitespace),
        "串-复制"           => string::string_copy,
        "串-追加"         => string::string_append,
        "串-替换-范围!" => string::string_replace_range_em,
        "制作-串"           => string::make_string,

        "载入"         => system::load,
        "文件-存在?" => system::file_exists_qm,
        "删除-文件"  => system::delete_file,
        "系统*"      => system::system_star,
        "取-环境-变量"  => system::get_environment_variable,
        "取-环境-变量复" => system::get_environment_variables,

        "打开-二进制-输入-文件"  => io::open_binary_input_file,
        "打开-二进制-输出-文件" => io::open_binary_output_file,
        "打开-输入-文件"  => io::open_input_file,
        "打开-输出-文件" => io::open_output_file,
        "读"             => io::read,
        "读-u8"          => io::read_u8,
        "读-行"        => io::read_line,
        "读-印刻"        => io::read_char,
        "读-全部"         => io::read_all,
        "写"            => io::write,
        "写-串"     => io::write_string,
        "显示"          => io::display,
        "新行"          => io::newline,
        "关闭-端口"       => io::close_port
    }
}
