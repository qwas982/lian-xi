use lexer::Token;
use parser::SExpr;
use parser::SExprs;
use evaluator::Args;
use evaluator::Extra;
use procedure::ProcedureData;
use env::EnvRef;
use env::Env;
use serr::{SErr, SResult};

pub fn define(args: Args) -> SResult<SExpr> {
    env_add(EnvAddType::Define, args)
}

pub fn set(args: Args) -> SResult<SExpr> {
    env_add(EnvAddType::Set, args)
}

pub fn lambda(args: Args) -> SResult<SExpr> {
    let env = args.env();
    let (params, body) = args.own_one_rest()?;
    ProcedureData::new_compound(params, body, &env)
}

pub fn apply(args: Args) -> SResult<SExpr> {
    let env = args.env();
    let evaled = args.evaled()?;
    let (proc, arg_list) = if evaled.len() == 2 {
         let (proc, arg_list_) = evaled.own_two()?;
         let arg_list = arg_list_.into_list()?;
         (proc, arg_list)
    } else if evaled.len() > 2 {
        let (proc, list) = evaled.own_one_rest()?;
        let mut iter = list.into_iter().peekable();
        let mut arg_list = vec![];
        while let Some(x) = iter.next() {
            if iter.peek().is_some() {
                arg_list.push(x);
            } else { // last elem
                arg_list.append(&mut x.into_list()?);
            }
        };
        (proc, arg_list)
    } else {
        bail!(WrongArgCount => 2 as usize, evaled.len())
    };

    // Because the proc will try to reevaluate the arguments,
    // need to quote them before calling proc.
    let args_quoted = arg_list.into_iter()
        .map(|x| quote!(x))
        .collect();

    proc.as_proc()?.apply(Args::new(args_quoted, &env))
}

pub fn let_(args: Args) -> SResult<SExpr> {
    let_generic(args, |expr, _, parent_env| expr.eval(parent_env))
}

pub fn let_star(args: Args) -> SResult<SExpr> {
    let_generic(args, |expr, env, _| expr.eval(env))
}

pub fn let_rec(args: Args) -> SResult<SExpr> {
    // FIXME: (letrec ([x y] [y x]) 3) will fail
    let_star(args)
}

pub fn quote(args: Args) -> SResult<SExpr> {
    if args.len() != 1 {
        bail!(WrongArgCount => 1 as usize, args.len())
    }

    Ok(args[0].clone())
}

pub fn quasiquote(mut args: Args) -> SResult<SExpr> {
    if args.len() != 1 {
        bail!(WrongArgCount => 1 as usize, args.len())
    }

    let level = match args.extra {
        Extra::QQLevel(x) => x + 1,
        _ => 1
    };

    args.extra = Extra::QQLevel(level);
    if level == 1 {
        eval_unquoted(args)
    } else if level > 1 {
        Ok(quasiquote!(eval_unquoted(args)?))
    } else {
        bail!("准引号的出错用法")
    }
}

pub fn unquote(args: Args) -> SResult<SExpr> {
    if args.len() != 1 {
        bail!(WrongArgCount => 1 as usize, args.len())
    }

    let level = match args.extra {
        Extra::QQLevel(x) => x - 1,
        _ => bail!("在准引号之外反引号的用法")
    };

    let env = args.env();
    let arg = args.own_one()?;

    if level == 0 {
        arg.eval(&env)
    } else if level > 0 {
        let args = Args::new_with_extra(vec![arg], Extra::QQLevel(level), &env);
        Ok(unquote!(eval_unquoted(args)?))
    } else {
        bail!("反引号的出错用法")
    }
}

pub fn eval_unquoted(args: Args) -> SResult<SExpr> {
    let arg = args.get(0)
        .ok_or_else(|| SErr::WrongArgCount(1,0))?;

    let level = match args.extra {
        Extra::QQLevel(x) => x,
        _ => bail!("`反引号` 不在 `准引号` 内")
    };

    match arg {
        SExpr::List(xs) => match xs[0] {
            SExpr::Atom(Token::Symbol(ref x)) if x.as_str() == "反引号" => {
                unquote(Args::new_with_extra(xs[1..].to_vec(), Extra::QQLevel(level), &args.env))
            },
            SExpr::Atom(Token::Symbol(ref x)) if x.as_str() == "准引号" => {
                quasiquote(Args::new_with_extra(xs[1..].to_vec(), Extra::QQLevel(level), &args.env))
            },
            SExpr::List(ref xs2) => {
                Ok(SExpr::List(vec![eval_unquoted(Args::new_with_extra(vec![SExpr::List(xs2.clone())], Extra::QQLevel(level), &args.env))?]))
            },
            _ => {
                let result = xs.iter()
                    .map(|x| eval_unquoted(Args::new_with_extra(vec![x.clone()], Extra::QQLevel(level), &args.env)))
                    .collect::<SResult<_>>();
                Ok(SExpr::List(result?))
            }
        },
        x => Ok(x.clone())
    }
}

//
// Helpers
//
#[derive(Clone, Copy)]
enum EnvAddType {
    Define,
    Set
}

fn env_add(t: EnvAddType, args: Args) -> SResult<SExpr> {
    let env = args.env();
    let name_expr = args.get(0)
        .ok_or_else(|| SErr::new_id_not_found("没有"))?
        .clone();

    let (id, value) = match name_expr {
        SExpr::Atom(Token::Symbol(id)) => {
            let value = args.get(1)
                .ok_or_else(|| SErr::new_expr_not_found("没有"))?;

            let value_sexpr = value.eval(&args.env)?;

            (id.clone(), value_sexpr)
        },
        SExpr::List(_) => {
            let (header, body) = args.own_one_rest()?;
            let (id, params) = header.list_own_one_rest()?;

            (id.into_symbol()?, ProcedureData::new_compound(SExpr::List(params), body, &env)?)
        },
        SExpr::DottedList(xs,y) => {
            let mut iter = xs.into_iter();
            let id = iter.next()
                .ok_or_else(|| SErr::new_generic("期望一个标识符, 一无所获."))?;
            let head = iter.take_while(|_| true).collect::<SExprs>();
            let (_, body) = args.own_one_rest()?;

            let arg_list = match head.len() {
                // (define (x . y) ...)
                0 => *y,
                // (define (x y ... . z) ...)
                _ => SExpr::DottedList(head, y)
            };

            (id.into_symbol()?, ProcedureData::new_compound(arg_list, body, &env)?)
        },
        x => return Err(SErr::new_id_not_found(&x.to_string()))
    };


    match t {
        EnvAddType::Define => {
            env.define(id.clone(), value);
            Ok(SExpr::Unspecified)
        },
        EnvAddType::Set => {
            env.set(id.clone(), value)
        }
    }
}

pub fn let_generic<F>(args: Args, mut eval_expr: F) -> SResult<SExpr>
where F: (FnMut(&SExpr,/*env:*/ &EnvRef,/*parent_env:*/&EnvRef) -> SResult<SExpr>) {
    let parent_env = args.env();
    let (bindings, body) = args.own_one_rest()?;

    let env = Env::new(parent_env.clone_ref())
        .into_ref();
    let bindings_list = bindings.into_list()?;

    for x in bindings_list {
        let bind = x.into_list()?;
        let id = bind.get(0)
            .ok_or_else(|| SErr::new_expr_not_found("没有"))?
            .clone()
            .into_symbol()?;

        let expr = bind.get(1)
            .ok_or_else(|| SErr::new_expr_not_found("没有"))?;

        env.define(id, eval_expr(expr, &env, &parent_env)?);
    }

    let mut result = None;
    for expr in body {
        result = Some(expr.eval(&env));
    }

    result.unwrap()
}

pub fn exit(args: Args) -> SResult<SExpr> {
    ::std::process::exit(0);
}
