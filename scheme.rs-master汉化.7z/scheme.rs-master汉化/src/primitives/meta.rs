use std::char;

use lexer::Token::*;
use parser::SExpr::*;
use parser::SExpr;
use serr::{SErr,SResult};
use evaluator::Args;
use port::PortData::*;

pub fn type_of(args: Args) -> SResult<SExpr> {
    let item = args.evaled()?.own_one()?;

    Ok(match item {
        Atom(Symbol(_)) => ssymbol!("符号"),
        Atom(Integer(_)) => ssymbol!("整数"),
        Atom(Fraction(_)) => ssymbol!("分数"),
        Atom(Float(_)) => ssymbol!("浮点"),
        Atom(Boolean(_)) => ssymbol!("布尔"),
        Atom(Chr(_)) => ssymbol!("印刻"),
        Atom(Str(_)) => ssymbol!("串"),
        Atom(_) => ssymbol!("原子"),
        List(_) => ssymbol!("列表"),
        DottedList(_,_) => ssymbol!("列表-点号"),
        Procedure(_) => ssymbol!("过程"),
        Port(TextualFileInput(_,_)) => ssymbol!("端口-文本-入"),
        Port(TextualFileOutput(_,_)) => ssymbol!("端口-文本-出"),
        Port(BinaryFileInput(_,_)) => ssymbol!("端口-二进制-入"),
        Port(BinaryFileOutput(_,_)) => ssymbol!("端口-二进制-出"),
        Port(StdInput(_)) => ssymbol!("端口-标准-入"),
        Port(StdOutput(_)) => ssymbol!("端口-标准-出"),
        Port(Closed) => ssymbol!("端口-关闭"),
        _ => bail!(Generic => "那是一回事吗?")
    })
}

pub fn convert_type(args: Args) -> SResult<SExpr> {
    let (typ, arg) = args.evaled()?.own_two()?;

    Ok(match typ {
        Atom(Symbol(ref t)) if t == "符号" => match arg {
            x@Atom(Symbol(_)) => x,
            x@Atom(Str(_)) => ssymbol!(x.into_str()?),
            Atom(Chr(x)) => ssymbol!(x.to_string()),
            x => bail!(Cast => "符号", x)
        },
        Atom(Symbol(ref t)) if t == "印刻" => match arg {
            x@Atom(Chr(_)) => x,
            Atom(Integer(x)) => {
                let result = char::from_u32(x as u32)
                    .ok_or_else(|| SErr::Cast("印刻".to_string(), sint!(x)))?;

                schr!(result)
            },
            Atom(Str(x)) => {
                let result = x.borrow()
                    .chars()
                    .next()
                    .ok_or_else(|| SErr::new_generic("不能转换空串到印刻."))?;

                schr!(result)
            },
            x => bail!(Cast => "印刻", x)
        },
        Atom(Symbol(ref t)) if t == "整数" => match arg {
            x@Atom(Integer(_)) => x,
            Atom(Chr(x)) => sint!(x as i64),
            x => bail!(Cast => "印刻", x)
        },
        Atom(Symbol(ref t)) if t == "串" => match arg {
            x@Atom(Str(_)) => x,
            Atom(Symbol(x)) => sstr!(x),
            Atom(Chr(x)) => sstr!(x.to_string()),
            List(xs) => {
                let result = xs.into_iter()
                    .map(|x| x.into_chr())
                    .collect::<SResult<String>>()?;

                sstr!(result)
            },
            DottedList(xs, y) => {
                let mut result = xs.into_iter()
                    .map(|x| x.into_chr())
                    .collect::<SResult<String>>()?;
                result.push(y.into_chr()?);

                sstr!(result)
            },
            x => bail!(Cast => "串", x)
        },
        Atom(Symbol(ref t)) if t == "列表" => match arg {
            Atom(Str(x)) => {
                let result = x.borrow()
                    .chars()
                    .map(|c| schr!(c))
                    .collect();

                List(result)
            },
            x@List(_) => x,
            DottedList(mut xs, y) => {
                xs.push(*y);
                List(xs)
            },
            x => bail!(Cast => "列表", x)
        },
        x => bail!(TypeMismatch => x.into_symbol()?, arg)
    })
}
