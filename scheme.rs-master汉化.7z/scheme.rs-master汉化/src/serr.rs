use std::fmt;
use std::error::Error;
use std::io;
use std::env;

use lexer::Token;
use parser::SExpr;

pub type SResult<T> = Result<T, SErr>;

#[derive(Debug)]
pub enum SErr {
    Generic(String),
    FoundNothing,
    EnvNotFound,
    DivisionByZero,
    UnexpectedForm(SExpr),
    UnexpectedToken(Token),
    NotExpectedToken(Token, Token),
    Cast(String, SExpr),
    UnboundVar(String),
    NotAProcedure(SExpr),
    WrongArgCount(/*expected: */usize, /*found: */usize),
    IndexOutOfBounds(/*max: */usize, /*requested: */usize),
    TypeMismatch(String, SExpr),
    WrongPort(/*proc: */String, /*port: */String),
    //TODO: what about Trace(String, Box<SErr>)

    // Converted errors
    IOErr(io::Error),
    VarErr(env::VarError)
}

impl fmt::Display for SErr {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        let output = match self {
            SErr::Generic(x) => x.to_string(),
            SErr::FoundNothing => "期待某个表达式或牌，什么也没找到.".to_string(),
            SErr::EnvNotFound => "未找到环境. (可能是一个未绑定的变量)".to_string(),
            SErr::DivisionByZero => "被零除".to_string(),
            SErr::UnexpectedForm(x) => format!("表达式非期望形式: {}", x),
            SErr::UnexpectedToken(x) => format!("不期望此牌: {}", x),
            SErr::NotExpectedToken(x, y) => format!("期望其中之一 {}, 找到 {}", x, y),
            SErr::Cast(typ, x) => format!("不能转换 {} 到 {}", x, typ),
            SErr::UnboundVar(x) => format!("未绑定变量: {}", x),
            SErr::NotAProcedure(x) => format!("应用了出错类型, 不是过程: {}", x),
            SErr::WrongArgCount(x, y) => format!("实参计数出错; 期望: {}, 找到: {}", x, y),
            SErr::IndexOutOfBounds(x, y) => format!("索引超界. 最大大小: {}, 请求的: {}", x, y),
            SErr::TypeMismatch(x, y) => format!("期望一个 {}, 找到的是: {}", x, y),
            SErr::WrongPort(x, y) => format!("不能应用函数 `{}` 到端口类型是 {}", x, y),
            SErr::IOErr(x) => x.to_string(),
            SErr::VarErr(x) => x.to_string()
        };

        write!(f, "{}", &output)
    }
}

impl Error for SErr {
    fn description(&self) -> &str {
        match self {
            SErr::Generic(_) => "一个错误.",
            SErr::FoundNothing => "期待某个表达式或牌, 什么也没找到.",
            SErr::EnvNotFound => "未找到环境. (可能是一个未绑定的变量)",
            SErr::DivisionByZero => "被零除",
            SErr::UnexpectedForm(_) => "表达式非期望形式.",
            SErr::UnexpectedToken(_) => "不期望此牌.",
            SErr::NotExpectedToken(_, _) => "不期望此牌.",
            SErr::Cast(_, _) => "转换失败.",
            SErr::UnboundVar(_) => "未绑定变量.",
            SErr::NotAProcedure(_) => "不是过程.",
            SErr::WrongArgCount(_, _) => "实参计数出错.",
            SErr::IndexOutOfBounds(_, _) => "索引超界.",
            SErr::TypeMismatch(_, _) => "类型不匹配.",
            SErr::WrongPort(_, _) => "端口类型出错.",
            SErr::IOErr(x) => x.description(),
            SErr::VarErr(x) => x.description()
        }
    }
}

impl SErr {
    pub fn new_generic(s: &str) -> SErr {
        SErr::Generic(s.to_string())
    }

    pub fn new_unbound_var(s: &str) -> SErr {
        SErr::UnboundVar(s.to_string())
    }

    pub fn new_unexpected_form(x: &SExpr) -> SErr {
        SErr::UnexpectedForm(x.clone())
    }

    pub fn new_id_not_found(s: &str) -> SErr {
        SErr::new_generic(&format!("期望一个标识符, 找到: {}", s))
    }

    pub fn new_expr_not_found(s: &str) -> SErr {
        SErr::new_generic(&format!("期望一个表达式, 找到: {}", s))
    }
}

impl From<io::Error> for SErr {
    fn from(error: io::Error) -> Self {
        SErr::IOErr(error)
    }
}

impl From<env::VarError> for SErr {
    fn from(error: env::VarError) -> Self {
        SErr::VarErr(error)
    }
}

#[macro_export]
macro_rules! serr {
    ($e:ident) => {
        return Err(SErr::$e);
    }
}

#[macro_export]
macro_rules! bail {
    ($e:expr) => {
        return Err(SErr::Generic(($e).into()));
    };
    ($fmt:expr, $($arg:tt)+) => {
        return Err(SErr::Generic(format!($fmt, $($arg)+)));
    };
    ($type:ident => $thing:expr) => {
        return Err(SErr::$type(($thing).into()));
    };
    ($type:ident => $($thing:expr),+) => {
        return Err(SErr::$type($(($thing).into()),+));
    };
}
