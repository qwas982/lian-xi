extern int fib(int a);

int get(int a) {
  return fib(a);
}
