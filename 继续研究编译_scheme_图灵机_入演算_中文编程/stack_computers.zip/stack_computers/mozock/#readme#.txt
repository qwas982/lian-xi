
These files are put here as a service.  I cannot support them
nor promise that they will actually work, but they do work
for me (running Windows 3.11 on a PC).  The advantage to using
them is that you can use a browser to read files off-line without
having the on-line access time meter running (or from a computer
that doesn't have network access).

To use them from a PC, copy all the files in this directory to
your hard disk.  Create a new program icon in the program
manager that points to NULLSOCK.EXE.  Be sure to set the working
directory to that same directory where the software resides on
your hard disk.  Then, run NULLSOCK.EXE.  An "unplugged" icon will
appear, which permits you to run winsock applications (such as
Netscape) and have them think that you are actually attached to
the internet.  Close the "unplugged" icon, and you can connect
to the network using your normal winsock software.

Nullsock clearly states that it is freeware.  Mozock is not
specific, but seems to be freeware and is widely available
at many sites on the net.
