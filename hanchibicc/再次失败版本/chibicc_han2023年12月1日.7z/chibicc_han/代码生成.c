#include "chibicc_han.h"

static int 深度;

static int 计数(void){
    static int 甲 = 1;
    return 甲++;
}

static void 推(void){
    printf(" push %%rax\n");
    深度++;
}

static void 弹(char *实参){
    printf(" pop %s\n", 实参);
    深度--;
}

// 将 '数目' 四舍五入为与 '对齐' 最接近的倍数,
// 例如, 对齐_到(5,8) 返回 8, 而 对齐_到(11,8) 返回 16.
static int 对齐_到(int 数目, int 对齐){
    return (数目 + 对齐 - 1) / 对齐 * 对齐;
}

//计算一个给定节点的绝对地址,
//若给定节点不在内存里,它将是错误.
static void 生成_地址(节点 *节点的){
    if(节点的->种类 == 节点_变量){
        
        printf(" lea %d(%%rbp), %%rax\n", 节点的->变量->偏移);
        return;
    }
    错误("非一个左值");
}

//为一个给定节点生成代码.
static void 生成_表达式(节点 *节点的){
    switch(节点的->种类){
    case 节点_数值:
        printf(" mov $%d, %%rax\n", 节点的->值);
        return;
    case 节点_否定:
        生成_表达式(节点的->左手塞);
        printf(" neg %%rax\n");
        return;
    
    case 节点_变量:
        生成_地址(节点的);
        printf(" mov (%%rax), %%rax\n");
        return;
    case 节点_赋值:
        生成_地址(节点的->左手塞);
        推();
        生成_表达式(节点的->右手塞);
        弹("%rdi");
        printf(" mov %%rax, (%%rdi)\n");
        return;
    }

    生成_表达式(节点的->右手塞);
    推();
    生成_表达式(节点的->左手塞);
    弹("%rdi");

    switch(节点的->种类){
    case 节点_加法:
        printf(" add %%rdi, %%rax\n");
        return;
    case 节点_减法:
        printf(" sub %%rdi, %%rax\n");
        return;
    case 节点_乘法:
        printf(" imul %%rdi, %%rax\n");
        return;
    case 节点_除法:
        printf(" cqo\n");
        printf(" idiv %%rdi\n");
        return;
    case 节点_相等:
    case 节点_不等:
    case 节点_小于:
    case 节点_小等:
        printf(" cmp %%rdi, %%rax\n");

        if(节点的->种类 == 节点_相等)
            printf(" sete %%al\n");
        else if(节点的->种类 == 节点_不等)
            printf(" setne %%al\n");
        else if(节点的->种类 == 节点_小于)
            printf(" setl %%al\n");
        else if(节点的->种类 == 节点_小等)
            printf(" setle %%al\n");
        
        printf(" movzb %%al, %%rax\n");
        return;
    }

    错误("无效表达式");
}

static void 生成_语句(节点 *节点的){
    switch(节点的->种类){

    case 节点_若: {
        int 读数 = 计数();
        生成_表达式(节点的->条件);
        printf(" cmp $0, %%rax\n");
        printf(" je .L.否则.%d\n", 读数);
        生成_语句(节点的->那么);
        printf(" jmp .L.终.%d\n", 读数);
        printf(".L.否则.%d:\n", 读数);
        if(节点的->否则)
            生成_语句(节点的->否则);
        printf(".L.终.%d:\n", 读数);
        return;
    }
    case 节点_块:
        for(节点 *节 = 节点的->块体; 节; 节 = 节->下一个)
            生成_语句(节);
        return;
    case 节点_返回:
        生成_表达式(节点的->左手塞);
        printf(" jmp .L.返回\n");
        return;
    case 节点_表达式_语句:
        生成_表达式(节点的->左手塞);
        return;
    }

    错误("无效语句");
}

//为本地变量分配偏移.
static void 分配_本地变量_偏移(函数 *程序){
    int 偏移 = 0;
    for(对象 *变量 = 程序->本地的; 变量; 变量 = 变量->下一个){
        偏移 = 偏移 + 8;
        变量->偏移 = -偏移;
    }
    程序->栈_大小 = 对齐_到(偏移, 16);
}

void 代码生成(函数 *程序){
    分配_本地变量_偏移(程序);

    printf(" .globl main\n");
    printf("main:\n");

    //序章(建栈)
    printf(" push %%rbp\n");
    printf(" mov %%rsp, %%rbp\n");
    printf(" sub $%d, %%rsp\n", 程序->栈_大小);

    //遍历其抽象句法树到发射汇编.
    生成_语句(程序->函体);
    assert(深度 == 0);

    printf(".L.返回:\n");
    printf(" mov %%rbp, %%rsp\n");
    printf(" pop %%rbp\n");
    printf(" ret\n");
}