#include "chibicc_han.h"

static int 深度;

static void 推(void){
    printf(" push %%rax\n");
    深度++;
}

static void 弹(char *实参){
    printf(" pop %s\n", 实参);
    深度--;
}

static void 生成_表达式(节点 *节点的){
    switch(节点的->种类){
    case 节点_数值:
        printf(" mov $%d, %%rax\n", 节点的->值);
        return;
    case 节点_否定:
        生成_表达式(节点的->左手塞);
        printf(" neg %%rax\n");
        return;
    }

    生成_表达式(节点的->右手塞);
    推();
    生成_表达式(节点的->左手塞);
    弹("%rdi");

    switch(节点的->种类){
    case 节点_加法:
        printf(" add %%rdi, %%rax\n");
        return;
    case 节点_减法:
        printf(" sub %%rdi, %%rax\n");
        return;
    case 节点_乘法:
        printf(" imul %%rdi, %%rax\n");
        return;
    case 节点_除法:
        printf(" cqo\n");
        printf(" idiv %%rdi\n");
        return;
    case 节点_相等:
    case 节点_不等:
    case 节点_小于:
    case 节点_小等:
        printf(" cmp %%rdi, %%rax\n");

        if(节点的->种类 == 节点_相等)
            printf(" sete %%al\n");
        else if(节点的->种类 == 节点_不等)
            printf(" setne %%al\n");
        else if(节点的->种类 == 节点_小于)
            printf(" setl %%al\n");
        else if(节点的->种类 == 节点_小等)
            printf(" setle %%al\n");
        
        printf(" movzb %%al, %%rax\n");
        return;
    }

    错误("无效表达式");
}

static void 生成_语句(节点 *节点的){
    if(节点的->种类 == 节点_表达式_语句){
        生成_表达式(节点的->左手塞);
        return;
    }

    错误("无效语句");
}

void 代码生成(节点 *节点的){
    printf(" .globl main\n");
    printf("main:\n");

    //遍历其抽象句法树到发射汇编.
    for(节点 *节 = 节点的; 节; 节 = 节->下一个){
        生成_语句(节);
        assert(深度 == 0);
    }

    printf(" ret\n");
}