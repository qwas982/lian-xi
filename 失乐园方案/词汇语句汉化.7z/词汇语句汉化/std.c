/*
 * The Sly Scheme standard procedures
 * Copyright (c) 2009 Alex Queiroz <asandroq@gmail.com>
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>

#include "sly.h"
#include "object.h"

/*
 * R5RS 6.2.5
 */

static int compare(sly_state_t* S, int c)
{
  int i, ret, nargs = sly_get_top(S);

  if(nargs == 0) {
    sly_push_string(S, "不能对比零数号");
    sly_error(S, 1);
  } else if(nargs == 1) {
    if(!sly_numberp(S, 0)) {
      sly_push_string(S, "不能对比单个非数号");
      sly_error(S, 1);
    } else {
      sly_push_boolean(S, 1);
    }
  } else {
    for(i = 0; i < nargs - 1; i++) {
      switch(c) {
      case 0:
        ret = sly_less_than(S, i, i+1);
        break;
      case 1:
        ret = sly_greater_than(S, i, i+1);
        break;
      default:
	abort();
      }
      if(!ret) {
	sly_push_boolean(S, 0);
	return 1;
      }
    }
    sly_push_boolean(S, 1);
  }

  return 1;
}

static int less_than(sly_state_t* S)
{
  return compare(S, 0);
}

static int greater_than(sly_state_t* S)
{
  return compare(S, 1);
}

static int plus(sly_state_t* S)
{
  int nargs = sly_get_top(S);

  if(nargs == 0) {
    sly_push_integer(S, 0);
  } else if(nargs == 1) {
    if(!sly_numberp(S, 0)) {
      sly_push_string(S, "不能添加单个非数号");
      sly_error(S, 1);
    }
  } else {
    sly_add(S, nargs);
  }

  return 1;
}

static int minus(sly_state_t* S)
{
  int nargs = sly_get_top(S);

  if(nargs == 0) {
    sly_push_string(S, "不够数号去减");
    sly_error(S, 1);
  } else if(nargs == 1) {
    sly_unary_minus(S, 0);
  } else  {
    sly_subtract(S, nargs);
  }

  return 1;
}

static int divide(sly_state_t* S)
{
  int nargs = sly_get_top(S);

  if(nargs == 0) {
    sly_push_string(S, "不够数号去除");
    sly_error(S, 1);
  } else if(nargs == 1) {
    sly_invert(S, 0);
  } else  {
    sly_divide(S, nargs);
  }

  return 1;
}

static int _round(sly_state_t* S)
{
  int nargs = sly_get_top(S);

  if(nargs != 1) {
    sly_push_string(S, "实参数号错");
    sly_error(S, 1);
  } else {
    sly_round(S, 0);
  }

  return 1;
}

static int quotient(sly_state_t* S)
{
  int nargs = sly_get_top(S);

  if(nargs != 2) {
    sly_push_string(S, "实参数号错");
    sly_error(S, 1);
  } else {
    sly_divide(S, 2);
  }

  return 1;
}

static int _remainder(sly_state_t* S)
{
  int nargs = sly_get_top(S);

  if(nargs != 2) {
    sly_push_string(S, "实参数号错");
    sly_error(S, 1);
  } else {
    sly_remainder(S, 0, 1);
  }

  return 1;
}

/*
 * R5RS 6.2.6
 */

static int number_to_string(sly_state_t* S)
{
  int nargs = sly_get_top(S);

  if(nargs != 1) {
    sly_push_string(S, "实参数号错");
    sly_error(S, 1);
  } else {
    sly_number_to_string(S, 0);
  }

  return 1;
}

/*
 * R5RS 6.3.2
 */

static int cons(sly_state_t* S)
{
  int nargs = sly_get_top(S);

  if(nargs != 2) {
    sly_push_string(S, "实参数号错");
    sly_error(S, 1);
  }

  sly_cons(S, 0, 1);

  return 1;
}

static int car(sly_state_t* S)
{
  int nargs = sly_get_top(S);

  if(nargs != 1) {
    sly_push_string(S, "实参数号错");
    sly_error(S, 1);
  }

  if(!sly_pairp(S, 0)) {
    sly_push_string(S, "不能抽取其非点对的切头");
    sly_error(S, 1);
  }

  sly_car(S, 0);

  return 1;
}

static int cdr(sly_state_t* S)
{
  int nargs = sly_get_top(S);

  if(nargs != 1) {
    sly_push_string(S, "实参数号错");
    sly_error(S, 1);
  }

  if(!sly_pairp(S, 0)) {
    sly_push_string(S, "不能提取其非点对的切尾");
    sly_error(S, 1);
  }

  sly_cdr(S, 0);

  return 1;
}

static int listp(sly_state_t* S)
{
  int nargs = sly_get_top(S);

  if(nargs != 1) {
    sly_push_string(S, "实参数号错");
    sly_error(S, 1);
  }

  if(sly_listp(S, 0)) {
    sly_push_boolean(S, 1);
  } else {
    sly_push_boolean(S, 0);
  }

  return 1;
}

/*
 * R5RS 6.3.3
 */

static int string_to_symbol(sly_state_t* S)
{
  int nargs = sly_get_top(S);

  if(nargs != 1) {
    sly_push_string(S, "实参数号错");
    sly_error(S, 1);
  }

  sly_string_to_symbol(S, 0);

  return 1;
}

static int symbol_to_string(sly_state_t* S)
{
  int nargs = sly_get_top(S);

  if(nargs != 1) {
    sly_push_string(S, "实参数号错");
    sly_error(S, 1);
  }

  sly_symbol_to_string(S, 0);

  return 1;
}

/*
 * R5RS 6.3.5
 */

static int stringp(sly_state_t* S)
{
  int nargs = sly_get_top(S);

  if(nargs != 1) {
    sly_push_string(S, "实参数号错");
    sly_error(S, 1);
  }

  if(sly_stringp(S, 0)) {
    sly_push_boolean(S, 1);
  } else {
    sly_push_boolean(S, 0);
  }

  return 1;
}

static int string_length(sly_state_t* S)
{
  uint32_t len;
  int nargs = sly_get_top(S);

  if(nargs != 1) {
    sly_push_string(S, "实参数号错");
    sly_error(S, 1);
  }

  len = sly_string_length(S, 0);
  sly_push_integer(S, len);

  return 1;
}

static int string_ref(sly_state_t* S)
{
  sly_char_t c;
  int i, nargs = sly_get_top(S);

  if(nargs != 2) {
    sly_push_string(S, "实参数号错");
    sly_error(S, 1);
  }

  if(!sly_stringp(S, 0)) {
    sly_push_string(S, "不能索引非串");
    sly_error(S, 1);
  }

  if(!sly_integerp(S, 1)) {
    sly_push_string(S, "不能索引串用一个非整数");
    sly_error(S, 1);
  }

  i = sly_to_integer(S, 1);
  c = sly_string_ref(S, i, 0);
  sly_push_char(S, c);

  return 1;
}

static int string_append(sly_state_t* S)
{
  int nargs = sly_get_top(S);

  if(nargs == 0) {
    sly_push_string(S, "不能追加零串");
    sly_error(S, 1);
  } else {
    sly_concat(S, nargs);
  }

  return 1;
}

/*
 * R5RS 6.3.6
 */

static int vectorp(sly_state_t* S)
{
  int nargs = sly_get_top(S);

  if(nargs != 1) {
    sly_push_string(S, "实参数号错");
    sly_error(S, 1);
  }

  if(sly_vectorp(S, 0)) {
    sly_push_boolean(S, 1);
  } else {
    sly_push_boolean(S, 0);
  }

  return 1;
}

static int make_vector(sly_state_t* S)
{
  int i, size, nargs = sly_get_top(S);

  if(nargs != 1 && nargs != 2) {
    sly_push_string(S, "实参数号错");
    sly_error(S, 1);
  }

  if(!sly_integerp(S, 0)) {
    sly_push_string(S, "非整数大小给定到向量: ");
    sly_push_value(S, 0);
    sly_error(S, 2);
  }

  size = sly_to_integer(S, 0);
  sly_push_vector(S, size);

  if(nargs == 2) {
    for(i = 0; i < size; i++) {
      sly_push_value(S, 1);
      sly_vector_set(S, i, -2);
    }
  }

  return 1;
}

static int vector_length(sly_state_t* S)
{
  uint32_t len;
  int nargs = sly_get_top(S);

  if(nargs != 1) {
    sly_push_string(S, "实参数号错");
    sly_error(S, 1);
  }

  len = sly_vector_length(S, 0);
  sly_push_integer(S, len);

  return 1;
}

static int vector_ref(sly_state_t* S)
{
  int i, nargs = sly_get_top(S);

  if(nargs != 2) {
    sly_push_string(S, "实参数号错");
    sly_error(S, 1);
  }

  if(!sly_vectorp(S, 0)) {
    sly_push_string(S, "不能索引非向量");
    sly_error(S, 1);
  }

  if(!sly_integerp(S, 1)) {
    sly_push_string(S, "不能索引向量用一个非整数");
    sly_error(S, 1);
  }

  i = sly_to_integer(S, 1);
  sly_vector_ref(S, i, 0);

  return 1;
}

static int vector_set(sly_state_t* S)
{
  int i, nargs = sly_get_top(S);

  if(nargs != 3) {
    sly_push_string(S, "实参数号错");
    sly_error(S, 1);
  }

  if(!sly_vectorp(S, 0)) {
    sly_push_string(S, "不能设置非向量");
    sly_error(S, 1);
  }

  if(!sly_integerp(S, 1)) {
    sly_push_string(S, "不能索引向量用一个非整数");
    sly_error(S, 1);
  }

  i = sly_to_integer(S, 1);
  sly_vector_set(S, i, 0);
  sly_pop(S, 1);

  return 1;
}

/*
 * R5RS 6.4
 */

static int procedurep(sly_state_t* S)
{
  int nargs = sly_get_top(S);

  if(nargs != 1) {
    sly_push_string(S, "实参数号错");
    sly_error(S, 1);
  }

  if(sly_procedurep(S, 0)) {
    sly_push_boolean(S, 1);
  } else {
    sly_push_boolean(S, 0);
  }

  return 1;
}

static int apply(sly_state_t* S)
{
  int nargs = sly_get_top(S);

  if(nargs < 2) {
    sly_push_string(S, "太少实参去应用");
    sly_error(S, 1);
  }

  if(!sly_procedurep(S, 0)) {
    sly_push_string(S, "不能应用非过程");
    sly_error(S, 1);
  }

  if(!sly_listp(S, -1)) {
    sly_push_string(S, "最后实参去应用必须是个点对");
    sly_error(S, 1);
  }

  sly_apply(S, 0, nargs-1);

  return 1;
}

/*
 * R5RS 6.5
 */

static int eval(sly_state_t* S)
{
  int nargs = sly_get_top(S);

  if(nargs != 1) {
    sly_push_string(S, "实参数号错");
    sly_error(S, 1);
  }

  sly_eval(S, 0);

  return 1;
}

static int load(sly_state_t* S)
{
  int nargs = sly_get_top(S);

  if(nargs != 1) {
    sly_push_string(S, "实参数号错");
    sly_error(S, 1);
  }

  sly_load_file(S, 0);

  return 1;
}

/*
 * R5RS 6.6.1
 */

static int input_portp(sly_state_t* S)
{
  int nargs = sly_get_top(S);

  if(nargs != 1) {
    sly_push_string(S, "实参数号错");
    sly_error(S, 1);
  }

  if(sly_input_portp(S, 0)) {
    sly_push_boolean(S, 1);
  } else {
    sly_push_boolean(S, 0);
  }

  return 1;
}

static int eof_objectp(sly_state_t* S)
{
  int nargs = sly_get_top(S);

  if(nargs != 1) {
    sly_push_string(S, "实参数号错");
    sly_error(S, 1);
  }

  if(sly_eof_objectp(S, 0)) {
    sly_push_boolean(S, 1);
  } else {
    sly_push_boolean(S, 0);
  }

  return 1;
}

static int output_portp(sly_state_t* S)
{
  int nargs = sly_get_top(S);

  if(nargs != 1) {
    sly_push_string(S, "实参数号错");
    sly_error(S, 1);
  }

  if(sly_output_portp(S, 0)) {
    sly_push_boolean(S, 1);
  } else {
    sly_push_boolean(S, 0);
  }

  return 1;
}

static int open_input_file(sly_state_t* S)
{
  int nargs = sly_get_top(S);

  if(nargs != 1) {
    sly_push_string(S, "实参数号错");
    sly_error(S, 1);
  }

  if(!sly_stringp(S, 0)) {
    sly_push_string(S, "文件名必须是个串: ");
    sly_push_value(S, 0);
    sly_error(S, 2);
  }

  sly_open_input_file(S);

  return 1;
}

static int open_output_file(sly_state_t* S)
{
  int nargs = sly_get_top(S);

  if(nargs != 1) {
    sly_push_string(S, "实参数号错");
    sly_error(S, 1);
  }

  if(!sly_stringp(S, 0)) {
    sly_push_string(S, "文件名必须是个串: ");
    sly_push_value(S, 0);
    sly_error(S, 2);
  }

  sly_open_output_file(S);

  return 1;
}

static int close_input_port(sly_state_t *S)
{
  int nargs = sly_get_top(S);

  if(nargs != 1) {
    sly_push_string(S, "实参数号错");
    sly_error(S, 1);
  }

  if(!sly_input_portp(S, 0)) {
    sly_push_string(S, "不能关闭非输入端口");
    sly_push_value(S, 0);
    sly_error(S, 2);
  }

  sly_close_input_port(S);

  return 0;
}

static int close_output_port(sly_state_t *S)
{
  int nargs = sly_get_top(S);

  if(nargs != 1) {
    sly_push_string(S, "实参数号错");
    sly_error(S, 1);
  }

  if(!sly_output_portp(S, 0)) {
    sly_push_string(S, "不能关闭非输出端口");
    sly_push_value(S, 0);
    sly_error(S, 2);
  }

  sly_close_output_port(S);

  return 0;
}

/*
 * R5RS 6.6.3
 */

static int write(sly_state_t* S)
{
  int nargs = sly_get_top(S);

  if(nargs != 1 && nargs != 2) {
    sly_push_string(S, "实参数号错");
    sly_error(S, 1);
  }

  if(nargs == 1) {
    sly_push_current_output_port(S);
  }

  sly_write(S, 0, 1);

  return 0;
}

static int display(sly_state_t* S)
{
  int nargs = sly_get_top(S);

  if(nargs != 1 && nargs != 2) {
    sly_push_string(S, "实参数号错");
    sly_error(S, 1);
  }

  if(nargs == 1) {
    sly_push_current_output_port(S);
  }

  sly_display(S, 0, 1);

  return 0;
}

static int newline(sly_state_t* S)
{
  int nargs = sly_get_top(S);

  if(nargs != 0 && nargs != 1) {
    sly_push_string(S, "实参数号错");
    sly_error(S, 1);
  }

  if(nargs == 0) {
    sly_push_current_output_port(S);
  }

  sly_newline(S, 0);

  return 0;
}

static int write_char(sly_state_t* S)
{
  int nargs = sly_get_top(S);

  if(nargs != 1 && nargs != 2) {
    sly_push_string(S, "实参数号错");
    sly_error(S, 1);
  }

  if(!sly_charp(S, 0)) {
    sly_push_string(S, "不能写非印刻: ");
    sly_push_value(S, 0);
    sly_error(S, 2);
  }

  if(nargs == 1) {
    sly_push_current_output_port(S);
  }

  sly_display(S, 0, 1);

  return 0;
}

/*
 * boxes
 */

static int box(sly_state_t *S)
{
  int nargs = sly_get_top(S);

  if(nargs != 1) {
    sly_push_string(S, "实参数号错");
    sly_error(S, 1);
  }

  sly_box(S);

  return 1;
}

static int boxp(sly_state_t *S)
{
  int nargs = sly_get_top(S);

  if(nargs != 1) {
    sly_push_string(S, "实参数号错");
    sly_error(S, 1);
  }

  if(sly_boxp(S, 0)) {
    sly_push_boolean(S, 1);
  } else {
    sly_push_boolean(S, 0);
  }

  return 1;
}

static int unbox(sly_state_t *S)
{
  int nargs = sly_get_top(S);

  if(nargs != 1) {
    sly_push_string(S, "实参数号错");
    sly_error(S, 1);
  }

  if(!sly_boxp(S, 0)) {
    sly_push_string(S, "不能拆盒非盒子!");
    sly_error(S, 1);
  }

  sly_unbox(S);

  return 1;
}

static int set_box(sly_state_t *S)
{
  int nargs = sly_get_top(S);

  if(nargs != 2) {
    sly_push_string(S, "实参数号错");
    sly_error(S, 1);
  }

  if(!sly_boxp(S, 0)) {
    sly_push_string(S, "不能设置非盒子!");
    sly_error(S, 1);
  }

  sly_set_box(S, 0);

  return 1;
}

/*
 * error handling
 */

static int error(sly_state_t* S)
{
  return sly_error(S, sly_get_top(S));
}

static sly_reg_t std_regs[] = {
  {"<", less_than},
  {">", greater_than},
  {"+", plus},
  {"-", minus},
  {"/", divide},
  {"环绕", _round},
  {"商", quotient},
  {"余数", _remainder},
  {"数号->串", number_to_string},
  {"构造", cons},
  {"切头", car},
  {"切尾", cdr},
  {"列表?", listp},
  {"串->符号", string_to_symbol},
  {"符号->串", symbol_to_string},
  {"串?", stringp},
  {"串-长度", string_length},
  {"串-引用", string_ref},
  {"串-追加", string_append},
  {"向量?", vectorp},
  {"制作-向量", make_vector},
  {"向量-长度", vector_length},
  {"向量-引用", vector_ref},
  {"向量-设置!", vector_set},
  {"过程?", procedurep},
  {"应用", apply},
  {"求值", eval},
  {"载入", load},
  {"文件终-对象?", eof_objectp},
  {"输入-端口?", input_portp},
  {"输出-端口?", output_portp},
  {"打开-输入-文件", open_input_file},
  {"打开-输出-文件", open_output_file},
  {"关闭-输入-端口", close_input_port},
  {"关闭-输出-端口", close_output_port},
  {"写", write},
  {"显示", display},
  {"新行", newline},
  {"写-印刻", write_char},
  {"盒子", box},
  {"盒子?", boxp},
  {"拆盒", unbox},
  {"设置-盒子!", set_box},
  {"错误", error},
  {NULL, NULL}
};

int sly_open_std(sly_state_t* S)
{
  sly_register(S, std_regs);

  return 0;
}

